package Prozentrechnung;

public class Aufgaben {

}
