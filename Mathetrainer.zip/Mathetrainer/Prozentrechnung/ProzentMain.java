package Prozentrechnung;

public class ProzentMain {

	public static void main(String[] args) {
		ProzentTrainingView view = new ProzentTrainingView();
		ProzentModell modell = new ProzentModell();
		new ProzentController(view, modell);
	}
}
